//
// Created by Simone on 05/11/22.
//

#ifndef ELOQUENTESP32CAM_ESP32CAM_H
#define ELOQUENTESP32CAM_ESP32CAM_H

#include "./defines.h"
#include "./esp32cam/Cam.h"

#endif //ELOQUENTESP32CAM_ESP32CAM_H
